import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Dinosaurs extends PApplet {

/**
  The Dinosaur class creates a Dinosaur that the user attempts to avoid. 
  If the user is hit by a Dinosaur, they will lose health. 
  If the Dinosaur is a powerup, the user will gain health. 
  Dinosaurs disappear after they are hit or reach the bottom of the screen.
*/
class Dinosaur {
  int x, y, speed, health; // attributes of dinoaur
  PImage dinosaur; // image of dinosaur
  int rand; // random number for dinosaur type
  boolean isPu; // whether or not it is a powerup

  
  /**
    Constructor
    Constructs a Dinosaur at location x,y and with a width of w and a height of h
    @param int x
    @param int y
    @param int w
    @param int h
  */
  Dinosaur(int x, int y) {
    this.x = x;
    this.y = y;
    
    // set health equal to 10
    health = 10; 
    
    // set random speed
    speed = PApplet.parseInt(random(5, 11));
    
    // by default, dinosaur is not a powerup
    isPu = false;
    
    // get random integer
    rand = PApplet.parseInt(random(1, 10));
    
    if (random(100)>90) {
      // 10% of the time, dinosaur is a powerup
      isPu = true;
      dinosaur = loadImage("powerup.png");
    } else {
      // not a powerup
      isPu = false;
      
      // set image of dinosaur based on random number
      if (rand == 1) {
        dinosaur = loadImage ("Dinos-1.png");
      } else if (rand == 2) {
        dinosaur = loadImage ("Dinos-2.png");
      } else if (rand == 3) {
        dinosaur = loadImage ("Dinos-3.png");
      } else if (rand == 4) {
        dinosaur = loadImage ("Dinos-4.png");
      } else if (rand == 5) {
        dinosaur = loadImage ("Dinos-5.png");
      } else if (rand == 6) {
        dinosaur = loadImage ("Dinos-6.png");
      } else if (rand == 7) {
        dinosaur = loadImage ("Dinos-7.png");
      } else if (rand == 8) {
        dinosaur = loadImage ("Dinos-8.png");
      } else if (rand == 9) {
        dinosaur = loadImage ("Dinos-9.png");
      }
    }
  }
  
  /**
    Draws the dinosaur on the screen
  */
  public void display() {
    // displays the dinosaur
    imageMode(CENTER);
    image(dinosaur, x, y);
  }
  
  /**
    Moves the dinosaur down the screen
  */
  public void move() {
    y+=speed;
  }
  
  /**
    @return if the dinosaur has reached the bottom
  */ 
  public boolean reachedBottom() {
    // ternary statement
    // if the dinosaur is past the bottom, return true
    return (y>height+50) ? true : false;
  }
}
// declare global variables
Player p1;
StartScreen startScreen;
TitleScreen titleScreen;
Timeline timeline;
Resources resources;
Instructions instructions;
World world;

/**
  Initialize pages, player, and screen
*/
public void settings() {
  // set size of the frame
  size(1280, 720);
  // initialize player
  p1 = new Player(310, 170);
  
  // initialize the start screen, title screen, timeline page, resources page, and world
  startScreen = new StartScreen();
  titleScreen = new TitleScreen();
  timeline = new Timeline();
  resources = new Resources();
  instructions = new Instructions();
  world = new World(p1);
}

/**
  Draws the pages and game on the screen
*/
public void draw() {
  // if the user presses the Play button
  if (startScreen.startGame) {
    
    // draw the titleScreen
    if(titleScreen.play) { 
      // if the user presses the Start button to start playing the game
      world.restartGame = false;
      
      if(!world.endGame) {
        // if the user does not want to end the game, display the game
        world.display();
      } 
      if(world.restartGame) {
        
        // if the user wants to restart the game, go back to the title screen
        titleScreen.play = false;
        titleScreen.display();
      } else if (world.endGame) {
        
        // otherwise, if the user wants to end the game, display the end game screen
        background(0);
        imageMode(CORNER);
        image(world.thankYouImage, 0, 0);
      }
    } else if (titleScreen.instructions) { 
      // display the instructions
      instructions.display();
      
      // if the user presses the back arrow
      if(mousePressed && mouseX>1160 && mouseX<1215 && mouseY>65 && mouseY<115) {
        titleScreen.display();
        titleScreen.instructions = false;
        
        //startScreen.startGame = true;
      }
    } else {
      // display the title screen
      titleScreen.display();
      
      // display which level the user is on
      textSize(50);
      fill(255);
      text("Level " + world.curLevel, width/2, height/2-10);
      
      // if the user presses the back button, go back to the start screen
      if(mousePressed) {
        if(mouseX>1215 && mouseX<1270 && mouseY>15 && mouseY<65) {
          startScreen.startGame = false;
          startScreen.display();
        } else if (mouseX>width/2-140 && mouseX<width/2+140 && mouseY>570 && mouseY<700) {
          titleScreen.instructions = true;
          instructions.display();
        }
      }
    }
  } else if (startScreen.viewTimeline) { // if the user presses the Timeline button
  
    // display the timeline
    timeline.display();
    
    // if the user presses the back button, go back to the start screen
    if(mousePressed && mouseX>1215 && mouseX<1270 && mouseY>15 && mouseY<65) {
      startScreen.viewTimeline = false;
      startScreen.display();
    }
  } else if (startScreen.viewResources) { // if the user presses the Resources button
    
    // display the resources page
    resources.display();
    
    // if the user presses the back button, go back to the start screen
    if(mousePressed && mouseX>1215 && mouseX<1270 && mouseY>15 && mouseY<65) {
      startScreen.viewResources = false;
      startScreen.display();
    }
  } else {
    // otherwise, if the user does not do any actions, display the start screen
    startScreen.display();
  }
}
/**
  The Instructions page displays instructions on how to play the game.
*/

class Instructions{
  // declare global variables
  PImage background; // image of background
  PImage arrow; // image of back arrow
  
  /**
    Constructor
  */
  Instructions() {
    // initialize background and back arrow image
    background = loadImage("MazeTitleScreen.png");
    arrow = loadImage("arrow.png");
  }
  
  /**
    Displays the Instructions page
  */
  public void display() {
    // display the instructions page and the back arrow
    background(background);
    image(arrow, 1160, 65);
    
    // write title
    textSize(50);
    fill(255);
    textAlign(CENTER);
    text("Instructions", width/2, 150);
    
    // write instructions
    textSize(25);
    text("Reach the end of the maze without losing all of your health.", width/2, 300);
    text("Use the arrows on your keyboard to navigate.", width/2, 350);
    text("Dinosaurs will take away your health. Each dinosaur that you pass is 1 point.", width/2, 400);
    text("Hearts will increase your health by 10. Each heart also increases your score by 10.", width/2, 450);
  }
}
/**
  The Level class is used to create different levels of the game.
*/

class Level {
  // declare global variables
  PImage ground; // background
  PImage flags;
  ArrayList<Rectangle> rectangles; // ArrayList to hold walls
  int x, y, w, h; // end of maze target area
  int startX, startY; // starting location of player
  int dinoRate; // interval at which dinosaurs fall
  
  Level(int x, int y, int w, int h, int startX, int startY, int dinoRate) {
    // initialize and resize background to fit screen
    ground = loadImage("ground.jpg");
    ground.resize(1280, 720);
    flags = loadImage("flags-2.png");
    flags.resize(100, 100);
    
    // initialize rectangles ArrayList
    rectangles = new ArrayList();
    
    // initialize attributes
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.startX = startX;
    this.startY = startY;
    this.dinoRate = dinoRate;
  }
  
  /**
    Display the maze
  */
  public void display() {
    // display the background
    background(ground);
    fill(62, 153, 41);
    noStroke();
    rect(0, 650, width, 70);
  }
  
  /**
    Checks if the given point is inside the end of maze target area
    @param int x the x-coordinate being checked
    @param int y the y-coordinate being checked
  */
  public boolean won(int x, int y) {
    // returns if the given point is inside the end of maze target area
    return x>=this.x && x<=this.x+w && y>=this.y && y<=this.y+h;
  }
}
/**
  The LevelOne class is the first level of the game.
*/

class LevelOne extends Level {
  
  LevelOne() {
    // superconstructor
    super(1095, 100, 100, 100, 310, 170, 100); // construct Level
    
    // adds the interior maze walls to an ArrayList of Rectangles
    // will be used for collision detection
    rectangles.add(new Rectangle(400, 40, 60, 280)); // vertical
    rectangles.add(new Rectangle(180, 170, 60, 150)); // vertical
    rectangles.add(new Rectangle(230, 260, 170, 60)); // horizontal
    
    rectangles.add(new Rectangle(180, 420, 60, 150)); // vertical
    rectangles.add(new Rectangle(230, 420, 410, 60)); // horizontal
    rectangles.add(new Rectangle(640, 170, 60, 310)); // vertical
    rectangles.add(new Rectangle(690, 170, 180, 60)); // horizontal
    
    rectangles.add(new Rectangle(370, 540, 60, 140)); // vertical
    rectangles.add(new Rectangle(420, 540, 310, 60)); // horizontal
    
    rectangles.add(new Rectangle(1000, 40, 60, 440)); // vertical
    rectangles.add(new Rectangle(850, 420, 160, 60)); // horizontal
  }
  
  /**
    Displays the LevelOne maze
  */ 
  public void display(){
    // draw background
    background(ground);
    
    // set color of walls 
    fill(62, 153, 41);
    noStroke();
    
    // draw sides of maze
    rect(0, 0, 50, height); // vertical - left side
    rect(50, 0, width-50, 50); // horizontal - top
    rect(width-50, 0, 50, height); // vertical - right side
    rect(0, 650, width, 70); // horizontal - bottom
    
    // interior maze walls
    rect(400, 40, 60, 280); // vertical
    rect(180, 170, 60, 150); // vertical
    rect(230, 260, 170, 60); // horizontal
    
    rect(180, 420, 60, 150); // vertical
    rect(230, 420, 410, 60); // horizontal
    rect(640, 170, 60, 310); // vertical
    rect(690, 170, 180, 60); // horizontal
    
    rect(370, 540, 60, 140); // vertical
    rect(420, 540, 310, 60); // horizontal
    
    rect(1000, 40, 60, 440); // vertical
    rect(850, 420, 160, 60); // horizontal
    
    // draw end of maze target
    noFill();
    stroke(255);
    rect(x, y, w, h);
    imageMode(CENTER);
    image(flags, x+w/2,  y+h/2);
  }
}
/**
  The LevelTwo class is the second level of the game.
*/

class LevelTwo extends Level {
  
  /**
    Constructor
    Adds the interior maze walls to an ArrayList of Rectangles
  */
  LevelTwo() {
    // superconstructor
    super(1120, 530, 100, 100, 190, 180, 50); // construct Level
    
    // adds the interior maze walls to an ArrayList of Rectangles
    // will be used for collision detection
    rectangles.add(new Rectangle(40, 250, 260, 30));
    rectangles.add(new Rectangle(110, 340, 190, 30));
    rectangles.add(new Rectangle(270, 270, 30, 80));
    
    rectangles.add(new Rectangle(270, 110, 30, 70));
    rectangles.add(new Rectangle(110, 110, 170, 30));
    rectangles.add(new Rectangle(270, 270, 30, 80));
    
    rectangles.add(new Rectangle(110, 110, 170, 30));
    rectangles.add(new Rectangle(270, 270, 30, 80));
    
    rectangles.add(new Rectangle(380, 110, 340, 30));
    rectangles.add(new Rectangle(800, 110, 110, 30));
    rectangles.add(new Rectangle(900, 110, 30, 190));
    rectangles.add(new Rectangle(920, 270, 150, 30));
    rectangles.add(new Rectangle(1000, 110, 150, 30));
    rectangles.add(new Rectangle(1000, 110, 30, 90));

    rectangles.add(new Rectangle(400, 220, 380, 30));
    rectangles.add(new Rectangle(700, 440, 80, 30)); 
    rectangles.add(new Rectangle(770, 220, 30, 250));
    rectangles.add(new Rectangle(790, 370, 360, 30));
    rectangles.add(new Rectangle(410, 330, 260, 30));
    rectangles.add(new Rectangle(580, 350, 30, 120));

    rectangles.add(new Rectangle(1140, 110, 30, 290));
    rectangles.add(new Rectangle(1130, 480, 110, 30));
    rectangles.add(new Rectangle(1160, 330, 80, 30));
    
    rectangles.add(new Rectangle(120, 440, 30, 150));
    rectangles.add(new Rectangle(140, 440, 100, 30));
    rectangles.add(new Rectangle(240, 550, 30, 110));
    rectangles.add(new Rectangle(260, 550, 170, 30));
    rectangles.add(new Rectangle(520, 550, 360, 30));
    rectangles.add(new Rectangle(870, 480, 30, 100));
    rectangles.add(new Rectangle(890, 480, 130, 30));
    rectangles.add(new Rectangle(500, 460, 30, 200));
    rectangles.add(new Rectangle(340, 440, 250, 30));
  }
  
  /**
    Displays the LevelTwo maze
    Draws the sides and interior maze walls
  */ 
  public void display(){
    // draw background
    background(ground);
    
    // set color of walls 
    fill(62, 153, 41);
    noStroke();
    
    // draw sides of maze 
    rect(0, 0, 50, height); // vertical - left side
    rect(50, 0, width-50, 50); // horizontal - top
    rect(width-50, 0, 50, height); // vertical - right side
    rect(0, 650, width, 70); // horizontal - bottom
    
    // interior maze walls
    rect(40, 250, 260, 30); // horizontal
    rect(110, 340, 190, 30); // horizontal
    rect(270, 270, 30, 80); // vertical
    
    rect(270, 110, 30, 70); // vertical
    rect(110, 110, 170, 30); // horizontal
    
    rect(380, 110, 340, 30); // horizontal
    rect(800, 110, 110, 30); // horizontal
    rect(900, 110, 30, 190); // vertical
    rect(920, 270, 150, 30); // horizontal
    rect(1000, 110, 150, 30); // horizontal
    rect(1000, 110, 30, 90); // vertical
    
    rect(400, 220, 380, 30); // horizontal
    rect(700, 440, 80, 30); // horizontal
    rect(770, 220, 30, 250); // vertical
    rect(790, 370, 360, 30); // horizontal
    rect(410, 330, 260, 30); // horizontal
    rect(580, 350, 30, 120); // vertical
    
    rect(1140, 110, 30, 290); // vertical
    rect(1130, 480, 110, 30); // horizontal
    rect(1160, 330, 80, 30); // horizontal
    
    rect(120, 440, 30, 150); // vertical
    rect(140, 440, 100, 30); // horizontal
    rect(240, 550, 30, 110); // vertical
    rect(260, 550, 170, 30); // horizontal
    rect(520, 550, 360, 30); // horizontal
    rect(870, 480, 30, 100); // vertical
    rect(890, 480, 130, 30); // horizontal
    rect(500, 460, 30, 200); // vertical
    rect(340, 440, 250, 30); // horizontal
    
    // draw end of maze target
    noFill();
    stroke(255);
    rect(x, y, w, h);
    imageMode(CENTER);
    image(flags, x+w/2,  y+h/2);
  }
}
/**
  The Player class creates a Player that the user maneuvers.
  The user attempts to maneuver the Player to the end of the maze
  without losing all of their health.
*/

class Player {
  int x, y; // x and y coordinates of the player
  int health; // health of the player
  PImage player; // image of the player

  /**
    Constructor
  */
  Player(int x, int y) {
    // initialize location of the player
    this.x = x;
    this.y = y;
    
    // initialize health of player
    health = 100;
    
    // initialize and resize player image
    player = loadImage("Player.png");
    player.resize(48, 48);
  }
  
  /**
    Displays the player on the screen
    @param tempX x-coordinate of the player
    @param tempY y-coordinate of the player
  */
  public void display(int tempX, int tempY) {
    // set x and y to tempX and tempY
    x = tempX;
    y = tempY;
    
    // display player
    imageMode(CENTER);
    image(player, x, y);
  }
  
  /**
    Displays the player on the screen
  */
  public void display() {
    // display player
    imageMode(CENTER);
    image(player, x, y);
  }
}
/**
  The Rectangle class represents the walls of the maze.
*/

class Rectangle {
  // declare global variables
  int x; // x-coordinate of upper left corner
  int y; // y-coordinate of upper left corner
  int w; // width of rectangle
  int h; // height of rectangle
  boolean hit = false; // whether or not the player hit the rectangle
  
  /**
    Constructor
    @param int x x-coordinate of upper left corner
    @param int y y-coordinate of upper left corner
    @param int w width of rectangle
    @param int h height of rectangle
  */
  Rectangle(int x, int y, int w, int h) {
    // initialize attributes
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
  }
  
  /**
    @param Player p1 the player being tested
    @return if the player is in contact with the wall
  */
  public boolean collision(Player p1) {
    // by default, the player has not hit the rectangle
    hit = false;
    
    // if the player is in contact with the wall, they have hit the rectangle
    if(p1.x>=x-10 && p1.x<=x+w+10 && p1.y>=y-20 && p1.y<=y+h+20) {
      hit = true;
    }
    return hit;
  }

}
/**
  The Resources class contains links to websites with more information about dinosaurs.
*/

class Resources{
  // declare global variables
  PImage background; // image of resources page
  PImage arrow; // image of back arrow
  
  /**
    Constructor
  */
  Resources() {
    // initialize image of resources page
    background = loadImage("Resources.png");
    
    // initialize image of back arrow
    arrow = loadImage("arrow.png");
  }
  
  /**
    Displays the Resources page
  */
  public void display() {
    // display the resources image and the back arrow
    background(background);
    image(arrow, 1215, 15);
    
    // display the links
    textAlign(LEFT);
    textSize(20);
    fill(255);
    text("https://www.nationalgeographic.com/animals/facts/tyrannosaurus-rex", 100, 300);
    text("https://www.nhm.ac.uk/discover/dino-directory/brachiosaurus.html", 100, 350);
    text("https://www.nationalgeographic.com/animals/facts/triceratops-horridus", 100, 400);
    
    // if the mouse is hovering over one of the links, turn it blue and underline it
    if(mouseX>=100 && mouseX<=800 && mouseY>=280 && mouseY<=300) {
      fill(0, 0, 255);
      text("https://www.nationalgeographic.com/animals/facts/tyrannosaurus-rex", 100, 300);
      line(100, 300, 800, 300);
    } else if (mouseX>=100 && mouseX<=770 && mouseY>=330 && mouseY<=350) {
      fill(0, 0, 255);
      text("https://www.nhm.ac.uk/discover/dino-directory/brachiosaurus.html", 100, 350);
      line(100, 350, 770, 350);
    } else if (mouseX>=100 && mouseX<=815 && mouseY>=380 && mouseY<=400) {
      fill(0, 0, 255);
      text("https://www.nationalgeographic.com/animals/facts/triceratops-horridus", 100, 400);
      line(100, 400, 815, 400);
    }
    
    // if the mouse presses on a link, open it in the browser
    if(mousePressed) {
      println(mouseX + " " + mouseY);
      if(mouseX>=100 && mouseX<=800 && mouseY>=280 && mouseY<=300) {
        link("https://www.nationalgeographic.com/animals/facts/tyrannosaurus-rex");
      } else if (mouseX>=100 && mouseX<=770 && mouseY>=330 && mouseY<=350) {
        link("https://www.nhm.ac.uk/discover/dino-directory/brachiosaurus.html");
      } else if (mouseX>=100 && mouseX<=815 && mouseY>=380 && mouseY<=400) {
        link("https://www.nationalgeographic.com/animals/facts/triceratops-horridus");
      }
    }
  }
  
}
/**
  The StartScreen class is the main menu that is first 
  displayed when the user opens the application.
*/

class StartScreen {
  
  // declare global variables
  boolean startGame = false; // if user pressed play button
  boolean viewResources = false; // if user pressed resources button
  boolean viewTimeline = false; // if user pressed timeline button
  PImage startImage; // image of main menu
  
  /**
    Constructor
  */
  StartScreen(){
    // initialize image of main menu
    startImage = loadImage("MainMenu.png");
  }
  
  /**
    Displays the Start Screen
  */
  public void display() {
    
    // display the start screen image
    background(startImage);
    
    // display information about the game
    textAlign(CENTER);
    textSize(60);
    fill(255);
    text("Cretaceous Maze Adventure", width/2, 60);
    textSize(30);
    text("By Jonathan Widmer, Aiden DeBoer", width/2, height-150);
    text("Aaron Wang, William Bastian", width/2, height-120);
    text("Instructions:", width/2, height-90);
    text("Click on buttons to take you to different pages", width/2, height-60);
    text("Use the arrows to navigate", width/2, height-30);
    
    // if the user presses the mouse
    if (mousePressed) {
      if(mouseX>80 && mouseX<310 && mouseY>80 && mouseY <210) {
          // if user presses on the Play button, then set startGame to true
          startGame= true;
          viewTimeline = false;
          viewResources = false;
      } else if(mouseX>80 && mouseX<310 && mouseY>280 && mouseY<410) {
          // if user presses on the Play button, then set viewTimeline to true
          viewTimeline = true;
          startGame = false;
          viewResources = false;
      } else if(mouseX>80 && mouseX<310 && mouseY>480 && mouseY<610) {
          // if user presses on the Play button, then set viewResources to true
          viewResources = true;
          viewTimeline = false;
          startGame = false;
      }  
    }
  }
}
/**
  The Timeline page displays a timeline with more information about the dinosaurs.
*/

class Timeline{
  // declare global variables
  PImage background; // image of timeline
  PImage arrow; // image of back arrow
  
  /**
    Constructor
  */
  Timeline() {
    // initialize timeline and back arrow image
    background = loadImage("MazeTimeline.png");
    arrow = loadImage("arrow.png");
  }
  
  /**
    Displays the Timeline page
  */
  public void display() {
    // display the timeline and the back arrow
    background(background);
    image(arrow, 1215, 15);
  }
}
/**
  The Timer class is used to track how much time has passed. 
*/

class Timer {
  // declare global variables
  int savedTime; // when timer started
  int totalTime; // how long timer should last
  
  /**
    Constructor
    Constructs a Timer and sets TotalTime
  */
  Timer(int tempTotalTime) {
    totalTime = tempTotalTime;
  }
  
  
  /**
    Starts the Timer
  */
  public void start() {
    // when the timer starts it stores the current time in milliseconds
    savedTime = millis(); 
  }

  /**
    Returns true if 5,000 ms have passed.
    The work of the Timer is farmed out to this method.
  */
  public boolean isFinished() {
    // check how much time has passed
    int passedTime = millis()- savedTime;
    
    // ternary statement
    // return if passed time is more than total time
    return (passedTime>totalTime) ? true : false;
  }
}
/**
  The TitleScreen class is displayed before the user begins playing the game.
*/

class TitleScreen {
  PImage background; // background image
  PImage arrow; // back arrow
  boolean play = false; // the user has not begun playing yet
  boolean instructions = false;

  // constructor
  TitleScreen() {
    // initialize the images
    background = loadImage("TitleScreen.png");
    arrow = loadImage("arrow.png");
  }
  
  /**
    Display the title screen
  */
  public void display() {
    // display the background image and back arrow
    background(background);
    image(arrow, 1215, 15);
    
    fill(230);
    rect(width/2-140, 570, 280, 130);
    textMode(CENTER);
    fill(0);
    textSize(30);
    text("Instructions", width/2, 650);
    
    if(mousePressed) {
      println(mouseX + " " + mouseY);
    }
    
    // if the user presses on the start button, start the game
    if(mousePressed && mouseX>500 && mouseX<770 && mouseY>390 && mouseY<550) {
      play = true;
    }
  }
}
  
/**
  Displays the actual game, player, dinosaurs, and maze
*/
class World {
  // declare global variables
  ArrayList<Dinosaur> dinosaurs; // ArrayList of Dinosaurs
  ArrayList<Level> levels; // ArrayList of Levels
  Timer dinosaurTimer; // 
  Level levelOne; // level one
  Level levelTwo; // level two
  Level levelThree;
  
  int dinosaurRate = 100; // rate at which dinosaurs fall (in ms)
  int score = 0; // score of player
  int dinosaursPassed = 0; // dinosaurs that have passed
  int curLevel = 1; // current level
  int value = color(62, 153, 41); // color for the buttons
  
  boolean play = false; // 
  boolean win = false; // if the user has won
  boolean restartGame = false; // if the user wants to restart the game
  boolean endGame = false; // if the user wants to end the game
  boolean nextLevel = false; // if the user wants to go to the next level
  
  PImage startImage; // image of the 
  PImage gameOver;
  PImage winImage, thankYouImage;
  
  World(Player p1) {
    // initialize ArrayList containing Dinosaurs
    dinosaurs = new ArrayList<Dinosaur>();  
    
    // initialize LevelOne and LevelTwo and add to ArrayList
    levels = new ArrayList<Level>();
    levelOne = new LevelOne();
    levelTwo = new LevelTwo();
    levels.add(levelOne);
    levels.add(levelTwo);
    
    // initialize and start dinosaurTimer
    dinosaurTimer = new Timer(dinosaurRate);
    dinosaurTimer.start();
    
    // intialize and resize images
    startImage = loadImage("MainMenu.png");
    gameOver = loadImage("gameover.png");
    gameOver.resize(1280, 720);
    winImage = loadImage("winningscreen.png");
    winImage.resize(1280, 720);
    thankYouImage = loadImage("thanksForPlaying.png"); 
  }  
  
  /**
  * Displays the current level and maze, Dinosaurs, and Player.
  */
  public void display() {
    // display the current level
    levels.get(curLevel-1).display();
    
    // draw the info panel
    infoPanel();
    
    // write what level it is
    textSize(20);
    fill(255);
    text("Level: " + curLevel, 50, 35);
    
    // distribution of dinosaurs
    if (dinosaurTimer.isFinished()) {
      dinosaurs.add(new Dinosaur(PApplet.parseInt(random(width-100)+50), -50));
      dinosaurTimer.start();
    }
 
    // render dinosaurs
    // iterate through ArrayList of Dinosaurs
    for (int i = dinosaurs.size()-1; i>0; i--) {
      // get Dinosaur
      Dinosaur dinosaur = (Dinosaur) dinosaurs.get(i);
      
      // move dinosaur
      dinosaur.move();
      
      // display dinosaur
      dinosaur.display();
      
      // if the dinosaur reached the bottom, remove it, and increment the score
      if (dinosaur.reachedBottom()) {
        dinosaurs.remove(dinosaur);
        dinosaursPassed++;
        score+=1;
      }

      // player vs dinosaur collision
      // if distance between player and dinosaur is less than 25
      if (dist(p1.x, p1.y, dinosaur.x, dinosaur.y)<=25) {
        // if the dinosaur is a powerup, add 10 to the player health and score, and remove the powerup
        if (dinosaur.isPu) {
          p1.health+=10;
          score+=10;
          dinosaurs.remove(dinosaur);
        } else { 
          // otherwise remove the dinosaur's health and score from the player, and remove the dinosaur
          p1.health-=dinosaur.health;
          score-=dinosaur.health;
          dinosaurs.remove(dinosaur);
        }
      }
    }

    // using key controls to move the player
    Rectangle r = new Rectangle(0, 0, 0, 0);
    boolean hit = false;
    String dir = "";
    // check if wall and player have collided
    for(int i = 0; i < levels.get(curLevel-1).rectangles.size(); i ++) {
      if(levels.get(curLevel-1).rectangles.get(i).collision(p1)) {
        r = levels.get(curLevel-1).rectangles.get(i);
        hit = true;
      }
    }
    
    // determine what direction the wall is at
    if(hit) {
      if(p1.x<=r.x+4) {
        dir = "RIGHT";
      } else if (p1.x>=r.x+r.w-4) {
        dir = "LEFT";
      } else if (p1.y<=r.y+4) {
        dir = "DOWN";
      } else if (p1.y>=r.y+r.h-4) {
        dir = "UP";
      }
    }  
    
    // arrow controls for moving player
    // moves 3 units in the direction indicated
    if(keyPressed) {
      if(key == CODED) {
       if(keyCode==RIGHT && p1.x<width-60) {
         if(!hit || (!dir.equals("RIGHT"))) {
           p1.x += 3;
           p1.display();
         }
       } else if (keyCode==LEFT && p1.x>60) {       
         if(!hit || (!dir.equals("LEFT"))) {
           p1.x -= 3;
           p1.display();
         }
       } else if (keyCode==UP && p1.y>65) {
         if(!hit || (!dir.equals("UP"))) {
           p1.y -= 3;
           p1.display();
         }
       } else if (keyCode==DOWN && p1.y<height-90) {
         if(!hit || (!dir.equals("DOWN"))) {
           p1.y += 3;
           p1.display();
         }
       }
     } 
    }
    
    // check if user won
    win = levels.get(curLevel-1).won(p1.x, p1.y);
    
    // display the player
    p1.display();
    
    // debugging
    if (mousePressed) {
      println(mouseX + " " + mouseY);
    }
    
    //game over logic
    if (p1.health<1) {
      // if player died, go to losing screen
      play = false;
      dinosaurs.clear();
      gameOver();
    } else if (win) {
      // if player won, go to winning screen
      play = false;
      dinosaurs.clear();
      playerWon();
    } else {
      // otherwise, keep playing
      play = true;
    }
  }
  
  /**
    Displays an information panel about the player containing health, score, and dinosaurs passed
  */
  public void infoPanel() {
    // display score, health, and dinosaurs passed
    fill(255);
    textAlign(LEFT);
    textSize(15);
    text("Score: "+ score, 50, 690);
    text("Health: " + p1.health, 50, 710);
    text("Dinosaurs passed: " + dinosaursPassed, 50, 670);
  }
  
  /**
    Displays a GameOver screen if the user has lost (health<1)
    Displays buttons to play the level again or exit the game
  */
  public void gameOver() {
    // draw GameOver screen
    background(255);
    imageMode(CORNER);
    image(gameOver, 0, 0);
    textAlign(CENTER);
    fill(242, 66, 255);
    textSize(50);
    text("Game Over", width/2, height/3);
    text("Score: " + score, width/2, height/2+15);
    text("Dinosaurs Passed: " + dinosaursPassed, width/2, height/2+90);
    textSize(50);
    text("You lost!", width/2, height/2+150);
    
    // draw buttons to play the level again or exit the game
    fill(value);
    rect(50, height/2-175, 200, 100); // play again
    rect(50, height/2-50, 200, 100); // exit game
    fill(0);
    textSize(20);
    text("Play Again", 150, height/2-115);
    text("Exit Game", 150, height/2+10); 
    
    restartGame = false;
    endGame = false;
    
    // if the mouse presses on a button
    if (mousePressed){
      if(mouseX>=50 && mouseX<=250 && mouseY>=height/2-175 && mouseY<=height/2-75){
        // if the mouse presses the play again button, set restartGame to true
        restartGame = true;
      } else if (mouseX>=50 && mouseX<=250 && mouseY>=height/2-50 && mouseY<=height/2+50) {
        // if the mouse presses the exit game button, set endGame to true
        endGame = true;
      }
      
      if(restartGame){
        // if the user presses the restartGame button, reset everything 
        win = false;
        score = 0;
        dinosaursPassed = 0;
        p1.health = 100;
        p1.x = levels.get(curLevel-1).startX;
        p1.y = levels.get(curLevel-1).startY;
        dinosaurRate = levels.get(curLevel-1).dinoRate;
      } else if (endGame){
        // otherwise don't display the win screen and exit the game
        win = false;
      }
    }
  }
  
  /**
    Displays a winning screen if the player won (reached the target)
    Displays buttons to play the level again, exit the game, or go to the next level, if there is one
  */
  public void playerWon() {
    // draw the winning screen
    background(winImage);
    
    // draw player info
    textAlign(CENTER);
    textSize(40);
    fill(255);
    text("You win!", width/2, 60);
    text("Score: " + score, width/2, 110);
    text("Dinosaurs Passed: " + dinosaursPassed, width/2, 160);
    
    // draw buttons to play the level again, exit the game, or go to the next level, if there is one
    fill(value);
    rect(50, height/2-175, 200, 100); // play again
    rect(50, height/2-50, 200, 100); // exit game
    if(curLevel<2) {
      rect(50, height/2-300, 200, 100);
    }
    fill(0);
    textSize(20);
    text("Play Again", 150, height/2-115);
    text("Exit Game", 150, height/2+10); 
    if(curLevel<2) {
      text("Next Level", 150, height/2-240);
    }
    
    // by default, restartGame, endGame, and nextLevel are false
    restartGame = false;
    endGame = false;
    nextLevel = false;
    
    // if mouse presses on a button
    if (mousePressed){
      
      if(mouseX>=50 && mouseX<=250 && mouseY>=height/2-175 && mouseY<=height/2-75){
        // if the mouse presses the play again button, set restartGame to true
        restartGame = true;
        
      } else if (mouseX>=50 && mouseX<=250 && mouseY>=height/2-50 && mouseY<=height/2+50) {
        // if the mouse presses the exit game button, set endGame to true
        endGame = true;
        
      } else if (mouseX>=50 && mouseX<=250 && mouseY>=height/2-300 && mouseY<=height/2-200) {
        // if there is a next level
        if(curLevel<2) {
          
          // if the mouse presses the next level button, set nextLevel to true
          curLevel ++;
          nextLevel = true;
        }
      }
      
      if(restartGame){
        // if the user presses the restartGame button, reset everything 
        win = false;
        score = 0;
        dinosaursPassed = 0;
        p1.health = 100;
        p1.x = levels.get(curLevel-1).startX;
        p1.y = levels.get(curLevel-1).startY;
        dinosaurRate = levels.get(curLevel-1).dinoRate;
        
      } else if (endGame){
        // otherwise if the user presses the endGame button, don't display the win screen and exit the game
        win = false;
        
      } else if (nextLevel) {
        // otherwise if the user presses the nextLevel button, set the information to the next level
        win = false;
        score = 0;
        dinosaursPassed = 0;
        p1.health = 100;
        p1.x = levels.get(curLevel-1).startX;
        p1.y = levels.get(curLevel-1).startY;
        dinosaurRate = levels.get(curLevel-1).dinoRate;
      }
    }
  }
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--present", "--window-color=#666666", "--stop-color=#cccccc", "Dinosaurs" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
